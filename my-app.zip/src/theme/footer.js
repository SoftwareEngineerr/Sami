export const Footersection = {
    backgroundColor: "#353232",
    color: "white",
    padding: '50px 0',
    margin: "10px -8px",
    marginBottom: '-8px',
    marginTop: '20px',
    box:{
        maxWidth: '1350px',
        margin: 'auto'
    },
    heading:{
        paddingLeft: "15px"
    }
}