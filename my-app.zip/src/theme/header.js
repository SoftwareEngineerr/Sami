export const Header = {
    img:{
        maxWidth: '100px'
    }
}